// news-dynamic.js: Carga noticias dinámicamente usando una plantilla HTML externa
// Configurar aquí las noticias:
// No se preocupen por el orden, ya lo hace el código :DDD
const newsData = [
  {
    title: '¡Campeones Nacionales! Medalla Platino y Acreditación a WICO 2025',
    date: '24 de mayo de 2025',
    content: [
      '¡Lo hemos logrado! KID-IA destaca entre 300 proyectos de todo México y se lleva la presea Platino, junto a una acreditación para participar en la World Innovation & Creativity Olympics 2025, la cual se llevará a cabo en la capital de Corea del Sur, Seúl.',
      'La acreditación, ganada después de una brillante presentación en la Final Nacional de INFOMATRIX 2025, llevada a cabo en Ixtlahuaca de Rayón, Estado de México, es un reconocimiento al arduo trabajo y dedicación de nuestro equipo.',
      '¡Estamos emocionados de seguir adelante y representar a México en esta y más competencias en que participamos, con el objetivo de seguir impactando positivamente en la sociedad a través de la tecnología!',
      'Agradecemos a nuestra rectora, la Doctora Mara Grasiell Acosta González; a nuestra directora de carrera, la Maestra Mariana Soledad Centeno Sierra; a nuestros asesores, el Maestro José Antonio Rodríguez Ahumada y el Doctor Diego Arturo Soto Monterrubio; y a nuestra especialista en el área, la Licenciada en Psicología Teódula del Ángel Arteaga, por su apoyo incondicional.',
      '¡Vamos a seguir adelante y a marcar historia!',
      '한국에서 만나요!',
    ],
    media: [
      { type: 'img', src: '../images/news/24_05_2025/photo1.jpg', alt: 'Equipo con medallas y trofeo' },
      { type: 'img', src: '../images/news/24_05_2025/photo2.jpg', alt: 'Trofeo Platino' },
      { type: 'img', src: '../images/news/24_05_2025/photo3.jpg', alt: 'Jero posa' },
      { type: 'img', src: '../images/news/24_05_2025/photo4.jpg', alt: 'Vic posa' },
      { type: 'img', src: '../images/news/24_05_2025/photo5.jpg', alt: 'Rubén posa' },
      { type: 'img', src: '../images/news/24_05_2025/photo6.jpg', alt: 'Frame de premiación' },
      { type: 'img', src: '../images/news/24_05_2025/photo7.jpg', alt: 'Equipo junto a Stand' },
    ]
  },
  {
    title: '¡Contundente golpe en la mesa! KID-IA se clasifica a la final Nacional de INFOMATRIX 2025',
    date: '21 de febrero de 2025',
    content: [
      'En INFOMATRIX Golfo Norte 2025, nuestro proyecto "KID-IA: APLICACIÓN MÓVIL DIDÁCTICA E INTERACTIVA POTENCIADA POR INTELIGENCIA ARTIFICIAL PARA IMPULSAR EL DESARROLLO INTEGRAL DE PACIENTES CON TRASTORNO DEL ESPECTRO AUTISTA" fue galardonado con la Medalla de Plata y obtuvo la Acreditación al XIX Concurso Iberoamericano de Proyectos Estudiantiles de Ciencia y Tecnología - Final Nacional 2025, que se celebrará en Ixtlahuaca de Rayón, Estado de México.',
      'Este evento reunirá el talento de jóvenes investigadores de todo el país mexicano, y nosotros fuimos galardonados en participar tras obtener una acreditación y presea de plata en la fase regional de INFOMATRIX Golfo Norte 2025.',
      'Nuestro equipo de KID-IA está emocionado de tener la oportunidad de presentar todo el trabajo que se ha presentado. Víctor Villalón, Luis Jerónimo Loera y Rubén Rodríguez, de la mano del Doctor Diego Arturo Soto Monterrubio estarán representando a la Universidad Tecnológica de Altamira en este evento tan importante.',
      'No caben dudas de que este es un gran paso para KID-IA y para la inclusión educativa en México.',
    ],
    media: [
      { type: 'img', src: '../images/news/21_02_2025/photo_1.jpg', alt: 'Víctor posa junto al stand de presentación' },
      { type: 'img', src: '../images/news/21_02_2025/photo2.jpg', alt: 'Foto de Equipo' },
      { type: 'img', src: '../images/news/21_02_2025/photo3.jpg', alt: 'Diploma de Reconocimiento' },
      { type: 'img', src: '../images/news/21_02_2025/photo4.jpg', alt: 'Preseas Ganadas' },
      { type: 'img', src: '../images/news/21_02_2025/photo5.jpg', alt: 'Stand de presentación' },
    ]
  },
  {
    title: '¡KID-IA lo ha logrado! Nos vamos a Paraguay',
    date: '23 de marzo de 2025',
    content: [
      'Con orgullo en la boca y felicidad a tope, nos complace anunciar que KID-IA ha sido seleccionado para participar en la Feria Internacional de Ciencia y Tecnología 2025 (FerCyTec), que tomará lugar en la ciudad de Caacupé, en Paraguay.',
      'Este evento, que se llevará a cabo del 26 de octubre al 1 de noviembre de 2025, reunirá a jóvenes investigadores de todo el continente americano para compartir sus proyectos innovadores y creativos.',
      'Nuestro equipo de KID-IA está emocionado de tener la oportunidad de presentar todo el trabajo que se ha presentado.',
      'Agradecemos a nuestra rectora, la Doctora Mara Grasiell Acosta González; a nuestra directora de carrera, la Maestra Mariana Soledad Centeno Sierra; a nuestros asesores, el Maestro José Antonio Rodríguez Ahumada y el Doctor Diego Arturo Soto Monterrubio; y a nuestra especialista en el área, la Licenciada en Psicología Teódula del Ángel Arteaga, por su apoyo incondicional.',
      '¡Jajohecha Paraguáipe!',
    ],
    media: [
      { type: 'img', src: '../images/news/23_03_2025/photo_1.jpg', alt: 'Foto de Bienvenida FerCyTec' },
      { type: 'img', src: '../images/news/23_03_2025/photo_2.jpg', alt: 'Foto de Equipo 1' },
      { type: 'img', src: '../images/news/23_03_2025/photo_3.jpg', alt: 'Foto de Equipo 2' },
      { type: 'img', src: '../images/news/23_03_2025/photo_4.jpg', alt: 'Foto de Equipo 3' },
    ]
  },
  {
    title: '¡KID-IA inicia su recorrido internacional!',
    date: '6 de diciembre de 2024',
    content: [
      'Es gran honor para nosotros anunciar nuestra primera participación internacional de manera virtual en la fase Final de la Ruta Escolar Científica Internacional 2024-2025, de la cual participamos entre 176 proyectos provenientes de 11 países.',
      'Esta participación se llevará a cabo el 5 de diciembre de 2024, donde presentaremos nuestro proyecto KID-IA a través de nuestro asesor, el Doctor Diego Arturo Soto Monterrubio.',
      'Como siempre es de esperarse, agradecemos a todos los que nos apoyaron en este gran paso, incluyendo a nuestros asesores, el Maestro José Antonio Rodríguez Ahumada y el Doctor Diego Arturo Soto Monterrubio; nuestra directora de carrera la Maestra Mariana Soledad Centeno Sierra; nuestra rectora, la Doctora Mara Grasiell Acosta González; al igual que a nuestra especialista en el área, la Licenciada en Psicología Teódula del Ángel Arteaga.',
    ],
    media: [
      { type: 'img', src: '../images/news/06_12_2024/photo_1.jpg', alt: 'Foto de exposición 3' },
    ]
  },
  {
    title: '¡KID-IA participa por segunda vez!',
    date: '10 de octubre de 2024',
    content: [
      'Es un orgullo para nosotros anunciar nuestra segunda participación como KID-IA en el Encuentro de Jóvenes Investigadores Tamaulipas 2024.',
      'Este evento, organizado por la Secretaría de Educación de Tamaulipas y el Consejo Tamaulipeco de Ciencia y Tecnología (COTACYT), se llevará a cabo el 10 y 11 de octubre de 2024 en el Polyforum "Dr. Rodolfo Torre Cantú", donde se presentarán proyectos innovadores y creativos de estudiantes de diversas instituciones educativas del estado.',
      'Nuestro equipo de KID-IA estará allí para compartir nuestra visión sobre cómo la tecnología puede centrarse a fines humanitarios.',
      'Agradecemos a todos los que nos apoyaron en este gran paso, incluyendo a nuestros asesores, el Maestro José Antonio Rodríguez Ahumada y el Doctor Diego Arturo Soto Monterrubio; nuestra directora de carrera la Maestra Mariana Soledad Centeno Sierra; nuestra rectora, la Doctora Mara Grasiell Acosta González; al igual que a nuestra especialista en el área, la Licenciada en Psicología Teódula del Ángel Arteaga.',
      '¡A por la Victoria en Ciudad Victoria!'
    ],
    media: [
      { type: 'img', src: '../images/news/10_10_2024/EJIT_photo_1.jpeg', alt: 'Foto tomada con el mural del evento.' },
      { type: 'img', src: '../images/news/10_10_2024/EJIT_photo_2.jpeg', alt: 'Foto de exposición 1' },
      { type: 'img', src: '../images/news/10_10_2024/EJIT_photo_3.jpeg', alt: 'Foto de exposición 2' },
      { type: 'img', src: '../images/news/10_10_2024/EJIT_photo_4.jpeg', alt: 'Foto de exposición 3' },
    ]
  },
  {
    title: 'El inicio de una nueva era para la inclusión: KID-IA',
    date: '24 de septiembre de 2024',
    content: [
      'En este día nos commplace anunciar nuestra primera participación en el 26o Certamen Estatal de Creatividad e Innovación Tecnológica "ExpoCiencias Tamaulipas 2024" en su fase regional.',
      'Este proyecto, realizado por los estudiantes de la Universidad Tecnológica de Altamira, Víctor Eduardo Acosta Villalón y Ruben Alexander Rodríguez Muñoz, busca destinar el uso de la emergente inteligencia artificial al acompañamiento terapéutico de niños con autismo a través de la personalización de sus actividades de refuerzo.',
      'Gracias a todos los que nos apoyaron en este gran paso, incluyendo a nuestros asesores, el Maestro José Antonio Rodríguez Ahumada y el Doctor Diego Arturo Soto Monterrubio; nuestra directora de carrera la Maestra Mariana Soledad Centeno Sierra; nuestra rectora, la Doctora Mara Grasiell Acosta González; al igual que a nuestra especialista en el área, la Licenciada en Psicología Teódula del Ángel Arteaga.',
      '¡Gracias a todos los que nos apoyaron en este gran paso para la inclusión educativa!'
    ],
    media: [
      { type: 'img', src: '../images/news/24_09_2024/photo_1.jpg', alt: 'Reconocimiento del Equipo' },
      { type: 'img', src: '../images/news/24_09_2024/photo_2.jpg', alt: 'Foto con Algunos participantes' },
    ]
  },
];

async function loadNewsTemplate() {
  const response = await fetch('news-template.html');
  if (!response.ok) return null;
  return await response.text();
}

function renderMediaSlides(mediaArr) {
  return mediaArr.map(m => {
    if (m.type === 'img') {
      return `<div class="media-slide"><img src="${m.src}" alt="${m.alt || ''}"></div>`;
    } else if (m.type === 'video') {
      return `<div class="media-slide"><video src="${m.src}" controls preload="none"></video></div>`;
    }
    return '';
  }).join('');
}

function renderContentParagraphs(contentArr) {
  if (Array.isArray(contentArr)) {
    return contentArr.map(p => `<p>${p}</p>`).join('');
  }
  // Soporte retrocompatible para string
  return `<p>${contentArr}</p>`;
}

function fillTemplate(template, data, newsIndex) {
  return template
    .replace(/{{\s*title\s*}}/g, data.title)
    .replace(/{{\s*date\s*}}/g, data.date)
    .replace(/{{\s*content\s*}}/g, renderContentParagraphs(data.content))
    .replace(/{{\s*mediaSlides\s*}}/g, renderMediaSlides(data.media))
    .replace(/{{\s*newsIndex\s*}}/g, newsIndex);
}

window.addEventListener('DOMContentLoaded', async () => {
  const newsList = document.querySelector('.news-list');
  if (!newsList) return;
  const template = await loadNewsTemplate();
  if (!template) {
    newsList.innerHTML = '<p style="color:red">No se pudo cargar la plantilla de noticia.</p>';
    return;
  }
  newsList.innerHTML = '';
  // Ordenar las noticias por fecha descendente (más reciente primero)
  const sortedNews = newsData.slice().sort((a, b) => {
    const dateA = Date.parse(a.date) || Date.parse(a.date.split(' de ').reverse().join('-')) || 0;
    const dateB = Date.parse(b.date) || Date.parse(b.date.split(' de ').reverse().join('-')) || 0;
    return dateB - dateA;
  });
  sortedNews.forEach((news, idx) => {
    const html = fillTemplate(template, news, idx);
    const temp = document.createElement('div');
    temp.innerHTML = html.trim();
    newsList.appendChild(temp.firstElementChild);
  });
  initAllNewsSliders();
});

function initAllNewsSliders() {
  document.querySelectorAll('.news-media-slider').forEach((slider, idx) => {
    const track = slider.querySelector('.media-track');
    const slides = Array.from(track.children);
    const dotsContainer = slider.querySelector('.media-dots');
    let current = 0;
    let intervalId = null;
    // Crear dots
    dotsContainer.innerHTML = '';
    slides.forEach((_, i) => {
      const dot = document.createElement('span');
      dot.className = 'media-dot' + (i === 0 ? ' active' : '');
      dot.addEventListener('click', () => {
        goToSlide(i);
        resetInterval();
      });
      dotsContainer.appendChild(dot);
    });
    function goToSlide(idx) {
      current = idx;
      track.style.transform = `translateX(-${idx * 100}%)`;
      dotsContainer.querySelectorAll('.media-dot').forEach((dot, i) => {
        dot.classList.toggle('active', i === idx);
      });
    }
    function nextSlide() {
      goToSlide((current + 1) % slides.length);
    }
    function resetInterval() {
      clearInterval(intervalId);
      intervalId = setInterval(nextSlide, 3000);
    }
    // Inicializar
    track.style.display = 'flex';
    track.style.transition = 'transform 0.6s cubic-bezier(.77,0,.18,1)';
    slides.forEach(s => { s.style.flex = '0 0 100%'; });
    goToSlide(0);
    intervalId = setInterval(nextSlide, 3000);
    // Detener el slider al salir de la página
    window.addEventListener('beforeunload', () => clearInterval(intervalId));
  });
}
